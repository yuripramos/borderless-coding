# CHANGELOG.md

## [1.0.1] - 2023-05-06

- Dependencies update

## [1.0.0] - 2023-04-11

First release